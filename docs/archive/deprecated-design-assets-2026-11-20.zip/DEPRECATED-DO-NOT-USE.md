# Deprecated design history — not for implementation

Archived 2026-11-20 during asset cleanup. These files are superseded design studies or inspiration/provenance references, not approved runtime assets. Do not import them into Android resources or restore them into the active asset folders.

The current asset allowlist is docs/assets/README.md in the project. The approved moving renderer is smooth-joins v3. Paths inside this archive reproduce the earlier project layout for historical inspection; historical links and recommendations may be outdated.

MANIFEST.json records original paths, byte sizes and SHA-256 hashes. The original mockups/README.md is preserved here before its active index was refreshed. The archive contains 40 removed files and that prior index. The embedded prototypes are frozen historical snapshots.
