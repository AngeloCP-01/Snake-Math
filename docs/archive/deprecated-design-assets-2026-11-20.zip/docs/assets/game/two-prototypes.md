# Two rendering prototypes

> Historical comparison. The user subsequently approved the [grid gameplay prototype](snake-grid-gameplay-prototype.html) with [smooth-joins v3](path-snake/smooth-joins-v3.md); neither study below is the native implementation target.

Open `snake-comparison-prototype.html` to compare the two pages, or open either standalone file:

- `snake-sprites-prototype.html`: the actual fourteen-region illustrated sprite sheet, using the existing connector normalization.
- `snake-canvas-prototype.html`: all snake geometry, face and tail drawn in Canvas. No snake images or joints between separate character assets. Rounded head and tail caps intentionally follow the simpler reference direction.

Both use the same 12 × 8 checkerboard, 80px cells, snake routes, apples, grid overlay and controls. Parts stay inside occupied grid cells. The sprite connectors fill one cell width; the procedural stroke is 94% of a cell, leaving its outline inside the logical footprint. Head details are inside the endpoint cell. The original assembly prototype is preserved.

Controls: straight / turns / all directions; single step; play/pause at 550ms discrete intervals; grid toggle; PNG export. Demonstration stepping resets to the start of the route at its end; it is not final continuous animation, collision logic or an implemented Android game. No permanent state or external dependencies.

Sprite normalization remains a draft and can show distorted artwork and seams. The Canvas version intentionally uses a simpler procedural face and round tail, rather than trying to reproduce the illustrated home mascot. These pages compare rendering directions, not final skin artwork.

Verification: both scripts pass `node --check`. A temporary Node harness with a Canvas API shim exercises initial drawing, layout changes, step, grid, play/pause and export callbacks; it also checks route windows for adjacency, bounds, overlap and available sprite regions. This does not verify pixels or appearance. Browser visual inspection could not run because the browser-control connection returned an internal error when creating/selecting tabs.
