# Smooth body revision

> Historical revision. The final [smooth-joins v3](smooth-joins-v3.md) replaces the separate tail image with an integrated tail and feathers the head attachment. The live pages now show v3; use the saved v2 reference pages for this revision.

User direction: keep the approved gameplay, head and tail, but replace the tightly packed body sections with a smooth continuous spotted body similar to `image copy 5.png`.

Updated live pages: `../snake-grid-gameplay-prototype.html` and `../snake-path-prototype.html`. Previous versions remain in `../snake-grid-gameplay-segmented-reference.html` and `../snake-path-segmented-reference.html`.

The renderer now sweeps one body silhouette along the existing centerline, draws continuous shading ribbons across its width, and clips spaced oval markings into the surface. A short opacity blend covers the tail attachment without a flat body cap. Head and tail PNG regions, dimensions, rotation, anchoring and draw order are unchanged. No new artwork was generated; the source atlas is unchanged. Movement, collision, score, questions and lives were not edited.

The path-study page retains width, length and position controls. The old body-section spacing control was removed because the body is no longer made of repeated pods. This is a hybrid renderer: image head/tail plus procedural continuous body, with attachments calibrated to the coordinated artwork. The earlier unrelated head-only hybrid failure is not a guarantee that all hybrid rendering fails; matching artwork and attachment geometry remain essential.

Actual code renders were inspected in straight and curved poses and on the grid board. Preview files: `assembled-smooth-straight-v2.png`, `assembled-smooth-curve-v2.png`, `grid-mdas-smooth-v2.png`. The snapshot question for the saved grid image is `5 × 4 - 8 = ?`, answer 12.

Validation: both scripts pass syntax checks. Offscreen native Canvas executes the actual rendering and controls, including movement/pause and width/length changes; 648 geometry combinations and the existing 18 gameplay checks plus 1000 arithmetic questions pass. The temporary checker was adjusted to omit the deliberately removed spacing control. Browser screenshots and Android performance are not claimed.
